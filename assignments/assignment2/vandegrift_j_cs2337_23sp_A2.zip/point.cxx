// Jacob Vandegrift
// 1120903

#include "point.h"

namespace vandegrift_jacob {
    point::point(double x_, double y_) {
        x = x_;
        y = y_;
    }
}
